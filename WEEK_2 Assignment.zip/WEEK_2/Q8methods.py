#Methods

text2="python programming is good"

print(len(text2))
print(text2.capitalize())
print(text2.rstrip())
print(text2.isspace())
print(text2.startswith("python"))

modfified_text2=text2.replace("good", "easy")

print(modfified_text2)

new_text2=text2.split()

print(new_text2)