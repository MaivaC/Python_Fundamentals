#String manipulation

text = "I am learning Fundamentals of Programming in Python."

learning = "I will like to learn it"

final_text= text + learning

print(final_text)

print(text[16])
print(text[-10])
print(learning[11])
print(learning[-8])