# A code that displays name and age

name= input("What is your name?")
age= input("What is your age?")

print("My name is" , name)
print("I am ", age)