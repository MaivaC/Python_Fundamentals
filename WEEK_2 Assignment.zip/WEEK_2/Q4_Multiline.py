#Print a multiline string

books = """ I am not sure how much reading I need to do before asking this,
but have you ever seen/read a book by a Nigerian aunthor that has a happy ending?"""

print(books)












