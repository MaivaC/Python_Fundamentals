# Slicing Strings


print(text[3:23:2])
print(learning[-18:-3])
print(text[::])
