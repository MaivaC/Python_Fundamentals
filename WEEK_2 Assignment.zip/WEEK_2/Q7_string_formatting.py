#STRING FORMATTING

new_text="Python programming"
formatted_string="I am learning {}".format(new_text) #str.format method
print(formatted_string)

print(f"I am learning {new_text}")

