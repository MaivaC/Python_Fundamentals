Question 1

-Variables are container elements used for storage. They are used to store different data types.
-Variables are either global or local.
*Declaration*

name="Lucy"
age= 40
gpa= 3.05
fruits= [Oranges, Apples, Watermelon]

Question 2
Data types are classified under null, numeric, sequence ...
Some data types in python are "Intergers, List, Sets"

x = int(20) // x is an interger
books = list(Half of a yellow sun, Americannah, Broken people playlist) //This is a list. We use square brackets to represent them.
A = set(2,4,6,8,10)// This is a set of even numbers. It is represented using curly brackets.

Question 3

A modulous operator is an arithmetic operation that gives us a remainder when division occurs between two numbers. It ccould be used to also determine if a number is even or odd. It is represented using the percentage (%) sign.

9%3 = 0,  23%2 = 1.

