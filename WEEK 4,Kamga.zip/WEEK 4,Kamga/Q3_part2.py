#List slicing

fruits = ['apple', 'banana', 'orange', 'grape', 'mango']

print(fruits[1:3])