Question 1
Lists are mutable ordered colletion of elements. They are wriiten in square braces separated by a comma.Example: groceries= ["Milk", "Meat", "Eggs", "Meat"]

Tuples are immutable collection of items and they are witten in round braces. It supports two operations that is count and index.
Example:groceries=(milk, eggs, meat)

Question 3 part 1
List slicing is the act of separating a list into sections.

Question4 part 1
Tuples being immmutbale means they can't be modified. You can only count or index a tuple.


Question 6 part 1
add() adds a new element to an existing set while update() adds elements from one set into a set.

Question 8

A dictionary is a unordered collection of key-value pairs that have unique keys while a list is an ordered collection of items.

Dictionaries are written in curly braces while a list is written in square braces.

Key-value pairs are separated with semi-colons while elements in a list are separated using commas.