# Operations on dictionaries
#a)Changing the age to 21
student = {'name': 'John', 'age': 20, 'major': 'Computer Science'}
student['age']=21
print(student)

#b)Adding a new pair

student = {'name': 'John', 'age': 20, 'major': 'Computer Science'}
student['grade']= 'A'
print(student)