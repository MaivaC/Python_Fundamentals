#A command that modifies a list

numbers = [10, 20, 30, 40, 50]

numbers.insert(1, "25") #Changes 20 to 25
numbers.append(60)      #Add 60 at the end of the list

print(numbers)