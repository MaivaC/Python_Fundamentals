#intersection operations

set1 = {1, 2, 3, 4} 
set2 = {3, 4, 5, 6}
common_set=set1.intersection(set2)

print(common_set)